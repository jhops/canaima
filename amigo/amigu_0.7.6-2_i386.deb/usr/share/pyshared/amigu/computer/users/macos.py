# -*- coding: utf-8 -*-

from amigu.computer.users.base import generic_usr

class macuser(generic_usr):
    """Clase para el manejo de usarios Mac OS"""
    pass
